package com.xcompany.agentregistry.config;

import com.xcompany.agentregistry.entity.UsageEvent;
import com.xcompany.agentregistry.repository.UsageEventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;
import java.util.UUID;

@Component
@RequiredArgsConstructor
public class MockUsageDataLoader
        implements CommandLineRunner {

    private final UsageEventRepository repository;

    @Override
    public void run(String... args) {

        if (repository.count() > 0) {
            return;
        }

        Random random = new Random();

        List<String> agents =
                List.of(
                        "AGT-001",
                        "AGT-002",
                        "AGT-003",
                        "AGT-004"
                );

        List<String> teams =
                List.of(
                        "QA COE",
                        "Retail Lending",
                        "Payments",
                        "Platform Engineering"
                );

        for (int i = 0; i < 1000; i++) {

            UsageEvent event =
                    UsageEvent.builder()
                            .eventId(UUID.randomUUID().toString())
                            .agentId(
                                    agents.get(
                                            random.nextInt(
                                                    agents.size())))
                            .userId("user" + random.nextInt(200))
                            .team(
                                    teams.get(
                                            random.nextInt(
                                                    teams.size())))
                            .executionTimestamp(
                                    LocalDateTime.now()
                                            .minusDays(
                                                    random.nextInt(30)))
                            .durationMs(
                                    (long) random.nextInt(10000))
                            .status("SUCCESS")
                            .inputTokens(1000)
                            .outputTokens(2000)
                            .repository("sample-repo")
                            .build();

            repository.save(event);
        }
    }
}