package com.xcompany.agentregistry.config;


import com.xcompany.agentregistry.entity.Agent;
import com.xcompany.agentregistry.repository.AgentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
@RequiredArgsConstructor
public class SampleDataLoader implements CommandLineRunner {

    private final AgentRepository agentRepository;

    @Override
    public void run(String... args) {

        if (agentRepository.count() > 0) {
            return;
        }

        Agent agent = Agent.builder()
                .agentId("AGT-001")
                .agentName("API Test Generator")
                .description("Generates API automation tests")
                .ownerTeam("QA COE")
                .ownerEmail("qa@xcompany.com")
                .businessUnit("Engineering")
                .repository("api-test-generator-agent")
                .version("1.0.0")
                .status("ACTIVE")
                .visibility("ENTERPRISE")
                .telemetryEnabled(true)
                .complianceScore(100)
                .createdDate(LocalDate.now())
                .lastModifiedDate(LocalDate.now())
                .build();

        agentRepository.save(agent);
    }
}