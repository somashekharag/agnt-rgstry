package com.xcompany.agentregistry.controller;

import com.xcompany.agentregistry.entity.Agent;
import com.xcompany.agentregistry.repository.AgentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/agents")
@RequiredArgsConstructor
public class AgentController {

    private final AgentRepository repository;

    @GetMapping
    public List<Agent> getAgents() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public Agent getAgent(
            @PathVariable String id) {

        return repository.findById(id)
                .orElseThrow();
    }
}