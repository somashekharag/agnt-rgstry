package com.xcompany.agentregistry.controller;

import com.xcompany.agentregistry.entity.DuplicateCandidate;
import com.xcompany.agentregistry.service.DuplicateDetectionService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/duplicates")
@RequiredArgsConstructor
public class DuplicateController {

    private final DuplicateDetectionService service;

    @PostMapping("/scan")
    public Map<String, Object> scan() {

        int duplicates =
                service.scanDuplicates();

        return Map.of(
                "duplicatesFound",
                duplicates
        );
    }

    @GetMapping
    public List<DuplicateCandidate> getDuplicates() {

        return service.getDuplicates();
    }
}