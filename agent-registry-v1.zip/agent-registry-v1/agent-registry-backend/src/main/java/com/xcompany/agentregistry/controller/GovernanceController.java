package com.xcompany.agentregistry.controller;

import com.xcompany.agentregistry.dto.GovernanceScoreResponse;
import com.xcompany.agentregistry.dto.GovernanceSummaryResponse;
import com.xcompany.agentregistry.service.GovernanceService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/governance")
@RequiredArgsConstructor
public class GovernanceController {

    private final GovernanceService governanceService;

    @GetMapping("/scores")
    public List<GovernanceScoreResponse> scores() {

        return governanceService.calculateScores();
    }

    @GetMapping("/summary")
    public GovernanceSummaryResponse summary() {

        return governanceService.getSummary();
    }
}