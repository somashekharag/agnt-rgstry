package com.xcompany.agentregistry.controller;

import com.xcompany.agentregistry.dashboard.dto.NotificationDigestResponse;
import com.xcompany.agentregistry.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService service;

    @GetMapping("/new-agents")
    public Object newAgents() {

        return service.getNewAgents();
    }

    @GetMapping("/duplicate-candidates")
    public Object duplicates() {

        return service.getDuplicateCandidates();
    }

    @GetMapping("/top-agents")
    public Object topAgents() {

        return service.getTopAgents();
    }

    @GetMapping("/dormant-agents")
    public Object dormantAgents() {
        return service.getDormantAgents();
    }

    @GetMapping("/digest")
    public NotificationDigestResponse digest() {

        return service.buildDigest();
    }
}