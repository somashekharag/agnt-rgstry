package com.xcompany.agentregistry.controller;

import com.xcompany.agentregistry.scanner.ScanResult;
import com.xcompany.agentregistry.service.ScanService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/scan")
@RequiredArgsConstructor
public class ScanController {

    private final ScanService scanService;

    @PostMapping("/start")
    public ScanResult scan() throws Exception {

        return scanService.startScan();
    }
}