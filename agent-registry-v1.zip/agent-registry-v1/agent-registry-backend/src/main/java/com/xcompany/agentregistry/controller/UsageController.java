package com.xcompany.agentregistry.controller;

import com.xcompany.agentregistry.dto.UsageEventRequest;
import com.xcompany.agentregistry.dto.UsageSummaryResponse;
import com.xcompany.agentregistry.entity.UsageEvent;
import com.xcompany.agentregistry.service.UsageService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/usage")
@RequiredArgsConstructor
public class UsageController {

    private final UsageService usageService;

    @PostMapping("/events")
    public UsageEvent recordUsage(
            @RequestBody UsageEventRequest request) {

        return usageService.recordUsage(request);
    }

    @GetMapping("/summary")
    public UsageSummaryResponse summary() {

        return usageService.getSummary();
    }
}