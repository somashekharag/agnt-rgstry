package com.xcompany.agentregistry.dashboard;

import com.xcompany.agentregistry.dashboard.dto.DashboardOverviewResponse;
import com.xcompany.agentregistry.dashboard.dto.DormantAgentResponse;
import com.xcompany.agentregistry.dashboard.dto.TopAgentResponse;
import com.xcompany.agentregistry.dashboard.dto.TopTeamResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/dashboard")
@RequiredArgsConstructor
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping("/overview")
    public DashboardOverviewResponse overview() {

        return dashboardService.getOverview();
    }

    @GetMapping("/top-agents")
    public List<TopAgentResponse> topAgents() {

        return dashboardService.getTopAgents();
    }

    @GetMapping("/top-teams")
    public List<TopTeamResponse> topTeams() {

        return dashboardService.getTopTeams();
    }

    @GetMapping("/dormant-agents")
    public List<DormantAgentResponse> dormantAgents() {

        return dashboardService.getDormantAgents();
    }
}