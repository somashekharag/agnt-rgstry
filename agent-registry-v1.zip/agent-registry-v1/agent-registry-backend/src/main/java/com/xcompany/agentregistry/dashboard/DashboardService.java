package com.xcompany.agentregistry.dashboard;

import com.xcompany.agentregistry.dashboard.dto.DashboardOverviewResponse;
import com.xcompany.agentregistry.dashboard.dto.DormantAgentResponse;
import com.xcompany.agentregistry.dashboard.dto.TopAgentResponse;
import com.xcompany.agentregistry.dashboard.dto.TopTeamResponse;
import com.xcompany.agentregistry.dto.*;
import com.xcompany.agentregistry.entity.Agent;
import com.xcompany.agentregistry.entity.UsageEvent;
import com.xcompany.agentregistry.repository.AgentRepository;
import com.xcompany.agentregistry.repository.PromptRepository;
import com.xcompany.agentregistry.repository.SkillRepository;
import com.xcompany.agentregistry.repository.UsageEventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final AgentRepository agentRepository;

    private final SkillRepository skillRepository;

    private final PromptRepository promptRepository;

    private final UsageEventRepository usageEventRepository;

    public DashboardOverviewResponse getOverview() {

        long totalAgents = agentRepository.count();

        long totalSkills = skillRepository.count();

        long totalPrompts = promptRepository.count();

        long totalExecutions = usageEventRepository.count();

        long uniqueUsers =
                usageEventRepository.findAll()
                        .stream()
                        .map(UsageEvent::getUserId)
                        .distinct()
                        .count();

        long activeAgents =
                usageEventRepository.findAll()
                        .stream()
                        .map(UsageEvent::getAgentId)
                        .distinct()
                        .count();

        long dormantAgents =
                totalAgents - activeAgents;

        return new DashboardOverviewResponse(
                totalAgents,
                totalSkills,
                totalPrompts,
                totalExecutions,
                uniqueUsers,
                activeAgents,
                dormantAgents
        );
    }

    public List<TopAgentResponse> getTopAgents() {

        Map<String, Long> executionsByAgent =
                usageEventRepository.findAll()
                        .stream()
                        .collect(
                                Collectors.groupingBy(
                                        UsageEvent::getAgentId,
                                        Collectors.counting()
                                )
                        );

        return executionsByAgent.entrySet()
                .stream()
                .sorted(
                        Map.Entry.<String, Long>
                                        comparingByValue()
                                .reversed()
                )
                .limit(10)
                .map(entry -> {

                    Agent agent =
                            agentRepository.findById(
                                            entry.getKey())
                                    .orElse(null);

                    String agentName =
                            agent != null
                                    ? agent.getAgentName()
                                    : "Unknown";

                    return new TopAgentResponse(
                            entry.getKey(),
                            agentName,
                            entry.getValue()
                    );
                })
                .toList();
    }

    public List<TopTeamResponse> getTopTeams() {

        Map<String, Long> executionsByTeam =
                usageEventRepository.findAll()
                        .stream()
                        .collect(
                                Collectors.groupingBy(
                                        UsageEvent::getTeam,
                                        Collectors.counting()
                                )
                        );

        return executionsByTeam.entrySet()
                .stream()
                .sorted(
                        Map.Entry.<String, Long>
                                        comparingByValue()
                                .reversed()
                )
                .limit(10)
                .map(entry ->
                        new TopTeamResponse(
                                entry.getKey(),
                                entry.getValue()
                        ))
                .toList();
    }

    public List<DormantAgentResponse> getDormantAgents() {

        LocalDateTime cutoff =
                LocalDateTime.now().minusDays(30);

        Set<String> activeAgentIds =
                usageEventRepository.findAll()
                        .stream()
                        .filter(e ->
                                e.getExecutionTimestamp()
                                        .isAfter(cutoff))
                        .map(UsageEvent::getAgentId)
                        .collect(Collectors.toSet());

        return agentRepository.findAll()
                .stream()
                .filter(agent ->
                        !activeAgentIds.contains(
                                agent.getAgentId()))
                .map(agent ->
                        new DormantAgentResponse(
                                agent.getAgentId(),
                                agent.getAgentName(),
                                agent.getOwnerTeam()
                        ))
                .toList();
    }
}
