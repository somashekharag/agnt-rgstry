package com.xcompany.agentregistry.dashboard.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DashboardOverviewResponse {

    private long totalAgents;

    private long totalSkills;

    private long totalPrompts;

    private long totalExecutions;

    private long uniqueUsers;

    private long activeAgents;

    private long dormantAgents;
}