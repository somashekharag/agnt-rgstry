package com.xcompany.agentregistry.dashboard.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DormantAgentResponse {

    private String agentId;

    private String agentName;

    private String ownerTeam;
}