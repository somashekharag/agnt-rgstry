package com.xcompany.agentregistry.dashboard.dto;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class NotificationDigestResponse {

    private List<String> newAgents;

    private List<String> dormantAgents;

    private List<String> duplicateCandidates;

    private List<String> topAgents;
}