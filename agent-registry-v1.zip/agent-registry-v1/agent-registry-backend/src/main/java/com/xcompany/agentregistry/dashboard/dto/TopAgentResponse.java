package com.xcompany.agentregistry.dashboard.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TopAgentResponse {

    private String agentId;

    private String agentName;

    private long executions;
}