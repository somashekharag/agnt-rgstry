package com.xcompany.agentregistry.dashboard.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TopTeamResponse {

    private String team;

    private long executions;
}
