package com.xcompany.agentregistry.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class GovernanceScoreResponse {

    private String agentId;

    private String agentName;

    private Integer score;

    private String rating;
}