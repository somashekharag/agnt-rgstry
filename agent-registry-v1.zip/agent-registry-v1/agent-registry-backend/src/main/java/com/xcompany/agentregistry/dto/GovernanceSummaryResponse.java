package com.xcompany.agentregistry.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class GovernanceSummaryResponse {

    private long totalAgents;

    private long goldAgents;

    private long silverAgents;

    private long bronzeAgents;

    private long atRiskAgents;
}