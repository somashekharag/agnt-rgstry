package com.xcompany.agentregistry.dto;

public class ScanResponse {
}
