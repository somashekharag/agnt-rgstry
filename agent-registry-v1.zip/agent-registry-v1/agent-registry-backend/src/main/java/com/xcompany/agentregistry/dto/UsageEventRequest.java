package com.xcompany.agentregistry.dto;

import lombok.Data;

@Data
public class UsageEventRequest {

    private String eventId;

    private String agentId;

    private String userId;

    private String team;

    private Long durationMs;

    private String status;

    private Integer inputTokens;

    private Integer outputTokens;

    private String repository;
}