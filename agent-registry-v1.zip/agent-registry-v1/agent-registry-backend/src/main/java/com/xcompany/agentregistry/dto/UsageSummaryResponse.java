package com.xcompany.agentregistry.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UsageSummaryResponse {

    private long totalExecutions;

    private long uniqueUsers;

    private long activeAgents;

    private long dormantAgents;
}