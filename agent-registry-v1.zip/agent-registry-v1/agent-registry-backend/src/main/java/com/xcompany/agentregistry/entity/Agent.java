package com.xcompany.agentregistry.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "agents")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Agent {

    @Id
    private String agentId;

    private String agentName;

    @Column(length = 5000)
    private String description;

    private String ownerTeam;

    private String ownerEmail;

    private String businessUnit;

    private String repository;

    private String version;

    private String status;

    private String visibility;

    private Boolean telemetryEnabled;

    private Integer complianceScore;

    private LocalDate createdDate;

    private LocalDate lastModifiedDate;
}