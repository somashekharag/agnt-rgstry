package com.xcompany.agentregistry.entity;

import jakarta.persistence.*;
import lombok.*;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "duplicate_candidates")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DuplicateCandidate {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    private String sourceAgentId;

    private String sourceAgentName;

    private String candidateAgentId;

    private String candidateAgentName;

    private Integer similarityScore;

    private String status;
}