package com.xcompany.agentregistry.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "prompts")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Prompt {

    @Id
    private String promptId;

    private String promptName;

    private String promptType;

    private String version;

    @ManyToOne
    @JoinColumn(name = "agent_id")
    private Agent agent;
}