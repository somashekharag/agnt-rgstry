package com.xcompany.agentregistry.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "skills")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Skill {

    @Id
    private String skillId;

    private String skillName;

    private String category;

    private String version;

    private String ownerTeam;

    @ManyToOne
    @JoinColumn(name = "agent_id")
    private Agent agent;
}