package com.xcompany.agentregistry.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "usage_events")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UsageEvent {

    @Id
    private String eventId;

    private String agentId;

    private String userId;

    private String team;

    private LocalDateTime executionTimestamp;

    private Long durationMs;

    private String status;

    private Integer inputTokens;

    private Integer outputTokens;

    private String repository;
}