package com.xcompany.agentregistry.repository;

import com.xcompany.agentregistry.entity.Agent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AgentRepository extends JpaRepository<Agent, String> {
    boolean existsByAgentId(String agentId);
}