package com.xcompany.agentregistry.repository;

import com.xcompany.agentregistry.entity.DuplicateCandidate;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DuplicateCandidateRepository
        extends JpaRepository<DuplicateCandidate, String> {
}