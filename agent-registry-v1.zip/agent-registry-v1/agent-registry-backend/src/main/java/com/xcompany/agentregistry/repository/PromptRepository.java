package com.xcompany.agentregistry.repository;

import com.xcompany.agentregistry.entity.Prompt;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PromptRepository extends JpaRepository<Prompt, String> {
}