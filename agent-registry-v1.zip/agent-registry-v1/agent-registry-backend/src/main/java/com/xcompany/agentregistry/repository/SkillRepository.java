package com.xcompany.agentregistry.repository;

import com.xcompany.agentregistry.entity.Skill;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SkillRepository extends JpaRepository<Skill, String> {

}