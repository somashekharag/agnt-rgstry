package com.xcompany.agentregistry.repository;

import com.xcompany.agentregistry.entity.UsageEvent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UsageEventRepository
        extends JpaRepository<UsageEvent, String> {

    long countByAgentId(String agentId);

    List<UsageEvent> findByAgentId(String agentId);

}