package com.xcompany.agentregistry.scanner;

import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.Yaml;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

@Component
public class FrontMatterParser {

    public Map<String, Object> parse(Path file) throws IOException {

        String content = Files.readString(file);

        if (!content.startsWith("---")) {
            throw new RuntimeException(
                    "Invalid frontmatter in file: " + file.getFileName());
        }

        String[] sections = content.split("---");

        if (sections.length < 2) {
            throw new RuntimeException(
                    "Frontmatter not found in file: " + file.getFileName());
        }

        String yamlContent = sections[1];

        Yaml yaml = new Yaml();

        return yaml.load(yamlContent);
    }
}
