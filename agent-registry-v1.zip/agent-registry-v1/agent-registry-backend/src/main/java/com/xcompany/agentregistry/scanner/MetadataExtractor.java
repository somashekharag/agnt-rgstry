package com.xcompany.agentregistry.scanner;

import com.xcompany.agentregistry.entity.Agent;
import com.xcompany.agentregistry.entity.Prompt;
import com.xcompany.agentregistry.entity.Skill;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Map;

@Component
public class MetadataExtractor {

    public Agent buildAgent(Map<String, Object> metadata) {

        return Agent.builder()
                .agentId((String) metadata.get("agentId"))
                .agentName((String) metadata.get("agentName"))
                .description((String) metadata.get("description"))
                .ownerTeam((String) metadata.get("ownerTeam"))
                .ownerEmail((String) metadata.get("ownerEmail"))
                .businessUnit((String) metadata.get("businessUnit"))
                .repository((String) metadata.get("repository"))
                .version((String) metadata.get("version"))
                .status((String) metadata.get("status"))
                .visibility((String) metadata.get("visibility"))
                .telemetryEnabled(
                        (Boolean) metadata.getOrDefault(
                                "telemetryEnabled",
                                false))
                .complianceScore(100)
                .createdDate(LocalDate.now())
                .lastModifiedDate(LocalDate.now())
                .build();
    }

    public Skill buildSkill(
            Map<String, Object> metadata,
            Agent agent) {

        return Skill.builder()
                .skillId((String) metadata.get("skillId"))
                .skillName((String) metadata.get("skillName"))
                .category((String) metadata.get("category"))
                .version((String) metadata.get("version"))
                .ownerTeam((String) metadata.get("ownerTeam"))
                .agent(agent)
                .build();
    }

    public Prompt buildPrompt(
            Map<String, Object> metadata,
            Agent agent) {

        return Prompt.builder()
                .promptId((String) metadata.get("promptId"))
                .promptName((String) metadata.get("promptName"))
                .promptType((String) metadata.get("promptType"))
                .version((String) metadata.get("version"))
                .agent(agent)
                .build();
    }
}