package com.xcompany.agentregistry.scanner;

import com.xcompany.agentregistry.entity.Agent;
import com.xcompany.agentregistry.entity.Prompt;
import com.xcompany.agentregistry.entity.Skill;
import com.xcompany.agentregistry.repository.AgentRepository;
import com.xcompany.agentregistry.repository.PromptRepository;
import com.xcompany.agentregistry.repository.SkillRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

@Component
@RequiredArgsConstructor
public class RepositoryScanner {

    private final FrontMatterParser parser;

    private final MetadataExtractor extractor;

    private final AgentRepository agentRepository;

    private final SkillRepository skillRepository;

    private final PromptRepository promptRepository;

    public ScanResult scanRepositories()
            throws IOException, URISyntaxException {

        int repositoriesScanned = 0;
        int agentsDiscovered = 0;
        int skillsDiscovered = 0;
        int promptsDiscovered = 0;

        URL resource =
                getClass()
                        .getClassLoader()
                        .getResource("mock-repositories");

        if (resource == null) {
            throw new RuntimeException(
                    "mock-repositories folder not found");
        }

        Path root = Paths.get(resource.toURI());

        repositoriesScanned =
                (int) Files.list(root)
                        .filter(Files::isDirectory)
                        .count();

        try (Stream<Path> files = Files.walk(root)) {

            for (Path file : files.toList()) {

                String fileName =
                        file.getFileName().toString();

                try {

                    // --------------------------------------------------
                    // AGENT FILES
                    // --------------------------------------------------

                    if (fileName.endsWith(".agent.md")) {

                        Map<String, Object> metadata =
                                parser.parse(file);

                        validateAgent(metadata, file);

                        Agent agent =
                                extractor.buildAgent(metadata);

                        /*
                         * save() acts as UPSERT
                         * INSERT if new
                         * UPDATE if exists
                         */
                        agentRepository.save(agent);

                        agentsDiscovered++;

                        continue;
                    }

                    // --------------------------------------------------
                    // SKILL FILES
                    // --------------------------------------------------

                    if (fileName.endsWith(".skill.md")) {

                        Map<String, Object> metadata =
                                parser.parse(file);

                        validateSkill(metadata, file);

                        String agentId =
                                extractAgentIdFromSkill(metadata);

                        Optional<Agent> agent =
                                agentRepository.findById(agentId);

                        if (agent.isEmpty()) {

                            System.out.println(
                                    "Skipping skill because agent not found: "
                                            + fileName);

                            continue;
                        }

                        Skill skill =
                                extractor.buildSkill(
                                        metadata,
                                        agent.get());

                        skillRepository.save(skill);

                        skillsDiscovered++;

                        continue;
                    }

                    // --------------------------------------------------
                    // PROMPT FILES
                    // --------------------------------------------------

                    if (fileName.endsWith(".prompt.md")) {

                        Map<String, Object> metadata =
                                parser.parse(file);

                        validatePrompt(metadata, file);

                        String agentId =
                                extractAgentIdFromPrompt(metadata);

                        Optional<Agent> agent =
                                agentRepository.findById(agentId);

                        if (agent.isEmpty()) {

                            System.out.println(
                                    "Skipping prompt because agent not found: "
                                            + fileName);

                            continue;
                        }

                        Prompt prompt =
                                extractor.buildPrompt(
                                        metadata,
                                        agent.get());

                        promptRepository.save(prompt);

                        promptsDiscovered++;
                    }

                } catch (Exception ex) {

                    System.err.println(
                            "Failed processing file: "
                                    + file);

                    ex.printStackTrace();
                }
            }
        }

        return new ScanResult(
                repositoriesScanned,
                agentsDiscovered,
                skillsDiscovered,
                promptsDiscovered);
    }

    // ==========================================================
    // VALIDATION
    // ==========================================================

    private void validateAgent(
            Map<String, Object> metadata,
            Path file) {

        if (metadata.get("agentId") == null) {

            throw new RuntimeException(
                    "agentId missing in "
                            + file.getFileName());
        }

        if (metadata.get("agentName") == null) {

            throw new RuntimeException(
                    "agentName missing in "
                            + file.getFileName());
        }
    }

    private void validateSkill(
            Map<String, Object> metadata,
            Path file) {

        if (metadata.get("skillId") == null) {

            throw new RuntimeException(
                    "skillId missing in "
                            + file.getFileName());
        }

        if (metadata.get("agentId") == null) {

            throw new RuntimeException(
                    "agentId missing in "
                            + file.getFileName());
        }
    }

    private void validatePrompt(
            Map<String, Object> metadata,
            Path file) {

        if (metadata.get("promptId") == null) {

            throw new RuntimeException(
                    "promptId missing in "
                            + file.getFileName());
        }

        if (metadata.get("agentId") == null) {

            throw new RuntimeException(
                    "agentId missing in "
                            + file.getFileName());
        }
    }

    // ==========================================================
    // HELPERS
    // ==========================================================

    private String extractAgentIdFromSkill(
            Map<String, Object> metadata) {

        return (String) metadata.get("agentId");
    }

    private String extractAgentIdFromPrompt(
            Map<String, Object> metadata) {

        return (String) metadata.get("agentId");
    }
}