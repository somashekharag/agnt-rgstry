package com.xcompany.agentregistry.scanner;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ScanResult {

    private int repositoriesScanned;

    private int agentsDiscovered;

    private int skillsDiscovered;

    private int promptsDiscovered;
}