package com.xcompany.agentregistry.service;

import com.xcompany.agentregistry.entity.Agent;
import com.xcompany.agentregistry.entity.DuplicateCandidate;
import com.xcompany.agentregistry.repository.AgentRepository;
import com.xcompany.agentregistry.repository.DuplicateCandidateRepository;
import com.xcompany.agentregistry.util.SimilarityUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class DuplicateDetectionService {

    private static final int THRESHOLD = 70;

    private final AgentRepository agentRepository;

    private final DuplicateCandidateRepository duplicateRepository;

    public int scanDuplicates() {

        duplicateRepository.deleteAll();

        List<Agent> agents =
                agentRepository.findAll();

        int duplicatesFound = 0;

        for (int i = 0; i < agents.size(); i++) {

            Agent source = agents.get(i);

            for (int j = i + 1; j < agents.size(); j++) {

                Agent target = agents.get(j);

                int score =
                        calculateScore(
                                source,
                                target);

                if (score >= THRESHOLD) {

                    DuplicateCandidate candidate =
                            DuplicateCandidate.builder()
                                    .sourceAgentId(
                                            source.getAgentId())
                                    .sourceAgentName(
                                            source.getAgentName())
                                    .candidateAgentId(
                                            target.getAgentId())
                                    .candidateAgentName(
                                            target.getAgentName())
                                    .similarityScore(score)
                                    .status(
                                            "POTENTIAL_DUPLICATE")
                                    .build();

                    duplicateRepository.save(candidate);

                    duplicatesFound++;
                }
            }
        }

        return duplicatesFound;
    }

    private int calculateScore(
            Agent source,
            Agent target) {

        int nameScore =
                SimilarityUtil.similarity(
                        source.getAgentName(),
                        target.getAgentName());

        int descriptionScore =
                SimilarityUtil.similarity(
                        source.getDescription(),
                        target.getDescription());

        return (int)
                ((nameScore * 0.4)
                        + (descriptionScore * 0.6));
    }

    public List<DuplicateCandidate> getDuplicates() {

        return duplicateRepository.findAll();
    }
}