package com.xcompany.agentregistry.service;

import com.xcompany.agentregistry.dto.GovernanceScoreResponse;
import com.xcompany.agentregistry.dto.GovernanceSummaryResponse;
import com.xcompany.agentregistry.entity.Agent;
import com.xcompany.agentregistry.repository.AgentRepository;
import com.xcompany.agentregistry.repository.UsageEventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class GovernanceService {

    private final AgentRepository agentRepository;

    private final UsageEventRepository usageEventRepository;

    public List<GovernanceScoreResponse> calculateScores() {

        return agentRepository.findAll()
                .stream()
                .map(this::calculateScore)
                .toList();
    }

    private GovernanceScoreResponse calculateScore(
            Agent agent) {

        int score = 0;

        if (agent.getOwnerTeam() != null
                && !agent.getOwnerTeam().isBlank()) {
            score += 20;
        }

        if (agent.getDescription() != null
                && !agent.getDescription().isBlank()) {
            score += 20;
        }

        if (Boolean.TRUE.equals(
                agent.getTelemetryEnabled())) {
            score += 20;
        }

        if ("ACTIVE".equalsIgnoreCase(
                agent.getStatus())) {
            score += 20;
        }

        long executions =
                usageEventRepository
                        .countByAgentId(
                                agent.getAgentId());

        if (executions > 0) {
            score += 20;
        }

        return new GovernanceScoreResponse(
                agent.getAgentId(),
                agent.getAgentName(),
                score,
                determineRating(score)
        );
    }

    private String determineRating(
            int score) {

        if (score >= 90) {
            return "GOLD";
        }

        if (score >= 70) {
            return "SILVER";
        }

        if (score >= 50) {
            return "BRONZE";
        }

        return "AT_RISK";
    }

    public GovernanceSummaryResponse getSummary() {

        List<GovernanceScoreResponse> scores =
                calculateScores();

        long gold =
                scores.stream()
                        .filter(s ->
                                "GOLD".equals(
                                        s.getRating()))
                        .count();

        long silver =
                scores.stream()
                        .filter(s ->
                                "SILVER".equals(
                                        s.getRating()))
                        .count();

        long bronze =
                scores.stream()
                        .filter(s ->
                                "BRONZE".equals(
                                        s.getRating()))
                        .count();

        long atRisk =
                scores.stream()
                        .filter(s ->
                                "AT_RISK".equals(
                                        s.getRating()))
                        .count();

        return new GovernanceSummaryResponse(
                scores.size(),
                gold,
                silver,
                bronze,
                atRisk
        );
    }
}