package com.xcompany.agentregistry.service;


import com.xcompany.agentregistry.dashboard.DashboardService;
import com.xcompany.agentregistry.dashboard.dto.NotificationDigestResponse;
import com.xcompany.agentregistry.entity.Agent;
import com.xcompany.agentregistry.entity.DuplicateCandidate;
import com.xcompany.agentregistry.repository.AgentRepository;
import com.xcompany.agentregistry.repository.DuplicateCandidateRepository;
import com.xcompany.agentregistry.repository.UsageEventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class NotificationService {

    private final AgentRepository agentRepository;

    private final DuplicateCandidateRepository duplicateRepository;

    private final UsageEventRepository usageRepository;

    private final DashboardService dashboardService;

    public List<String> getNewAgents() {

        LocalDate cutoff =
                LocalDate.now().minusDays(15);

        return agentRepository.findAll()
                .stream()
                .filter(agent ->
                        agent.getCreatedDate() != null &&
                        agent.getCreatedDate().isAfter(cutoff))
                .map(agent ->
                        agent.getAgentName()
                                + " (" +
                                agent.getOwnerTeam()
                                + ")")
                .toList();
    }

    public List<String> getDuplicateCandidates() {

        return duplicateRepository.findAll()
                .stream()
                .map(candidate ->
                        candidate.getSourceAgentName()
                                + " ↔ "
                                + candidate.getCandidateAgentName()
                                + " ("
                                + candidate.getSimilarityScore()
                                + "%)")
                .toList();
    }

    public List<String> getTopAgents() {

        return usageRepository.findAll()
                .stream()
                .collect(
                        Collectors.groupingBy(
                                e -> e.getAgentId(),
                                Collectors.counting()))
                .entrySet()
                .stream()
                .sorted(
                        (a,b) ->
                                Long.compare(
                                        b.getValue(),
                                        a.getValue()))
                .limit(5)
                .map(entry ->
                        entry.getKey()
                                + " ("
                                + entry.getValue()
                                + " executions)")
                .toList();
    }

    public NotificationDigestResponse buildDigest() {

        return NotificationDigestResponse.builder()
                .newAgents(getNewAgents())
                .duplicateCandidates(
                        getDuplicateCandidates())
                .topAgents(getTopAgents())
                .dormantAgents(getDormantAgents())
                .build();
    }

    public String buildTeamsMessage() {

        NotificationDigestResponse digest =
                buildDigest();

        return """
            AI Agent Registry Digest

            New Agents:
            %s

            Duplicate Candidates:
            %s

            Top Agents:
            %s
            """
                .formatted(
                        digest.getNewAgents(),
                        digest.getDuplicateCandidates(),
                        digest.getTopAgents()
                );
    }

    public List<String> getDormantAgents() {

        return dashboardService.getDormantAgents()
                .stream()
                .map(agent ->
                        agent.getAgentName()
                                + " ("
                                + agent.getOwnerTeam()
                                + ")")
                .toList();
    }
}