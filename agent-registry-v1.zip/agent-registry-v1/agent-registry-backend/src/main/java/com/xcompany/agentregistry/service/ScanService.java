package com.xcompany.agentregistry.service;

import com.xcompany.agentregistry.scanner.ScanResult;
import com.xcompany.agentregistry.scanner.RepositoryScanner;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ScanService {

    private final RepositoryScanner scanner;

    public ScanResult startScan() throws Exception {

        return scanner.scanRepositories();
    }
}