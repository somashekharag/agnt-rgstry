package com.xcompany.agentregistry.service;

import com.xcompany.agentregistry.dto.UsageEventRequest;
import com.xcompany.agentregistry.dto.UsageSummaryResponse;
import com.xcompany.agentregistry.entity.UsageEvent;
import com.xcompany.agentregistry.repository.UsageEventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UsageService {

    private final UsageEventRepository usageEventRepository;

    public UsageEvent recordUsage(
            UsageEventRequest request) {

        String eventId =
                request.getEventId() != null
                        ? request.getEventId()
                        : UUID.randomUUID().toString();

        if (usageEventRepository.existsById(eventId)) {

            return usageEventRepository
                    .findById(eventId)
                    .orElseThrow();
        }

        UsageEvent event =
                UsageEvent.builder()
                        .eventId(eventId)
                        .agentId(request.getAgentId())
                        .userId(request.getUserId())
                        .team(request.getTeam())
                        .durationMs(request.getDurationMs())
                        .status(request.getStatus())
                        .inputTokens(request.getInputTokens())
                        .outputTokens(request.getOutputTokens())
                        .repository(request.getRepository())
                        .executionTimestamp(LocalDateTime.now())
                        .build();

        return usageEventRepository.save(event);
    }

    public UsageSummaryResponse getSummary() {

        long totalExecutions =
                usageEventRepository.count();

        long uniqueUsers =
                usageEventRepository.findAll()
                        .stream()
                        .map(UsageEvent::getUserId)
                        .distinct()
                        .count();

        long activeAgents =
                usageEventRepository.findAll()
                        .stream()
                        .map(UsageEvent::getAgentId)
                        .distinct()
                        .count();

        return new UsageSummaryResponse(
                totalExecutions,
                uniqueUsers,
                activeAgents,
                0
        );
    }
}