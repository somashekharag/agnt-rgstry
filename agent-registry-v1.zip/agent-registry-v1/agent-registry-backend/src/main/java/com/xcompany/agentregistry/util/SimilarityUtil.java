package com.xcompany.agentregistry.util;

import org.apache.commons.text.similarity.LevenshteinDistance;

public class SimilarityUtil {

    private SimilarityUtil() {
    }

    public static int similarity(
            String first,
            String second) {

        if (first == null || second == null) {
            return 0;
        }

        first = first.toLowerCase();
        second = second.toLowerCase();

        int maxLength =
                Math.max(first.length(), second.length());

        if (maxLength == 0) {
            return 100;
        }

        int distance =
                LevenshteinDistance.getDefaultInstance()
                        .apply(first, second);

        return (int) (
                (1.0 -
                        ((double) distance / maxLength))
                        * 100
        );
    }
}