---
agentId: AGT-001
agentName: API Test Generator
description: Generates API tests from OpenAPI specs
ownerTeam: QA COE
ownerEmail: qa@xcompany.com
businessUnit: Engineering
repository: api-test-generator-agent
version: 1.0.0
status: ACTIVE
visibility: ENTERPRISE
telemetryEnabled: true
---

# API Test Generator