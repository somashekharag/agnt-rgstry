---
promptId: PRM-001
agentId: AGT-001
promptName: Generate API Tests
promptType: SYSTEM
version: 1.0.0
---