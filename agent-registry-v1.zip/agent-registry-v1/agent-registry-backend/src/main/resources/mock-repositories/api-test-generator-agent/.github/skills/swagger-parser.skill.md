---
skillId: SKL-002
agentId: AGT-001
skillName: Swagger Parser
category: API Testing
version: 1.0.0
---