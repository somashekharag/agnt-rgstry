import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:8080"
});

export const getOverview =
  () => api.get("/api/dashboard/overview");

export const getTopAgents =
  () => api.get("/api/dashboard/top-agents");

export const getTopTeams =
  () => api.get("/api/dashboard/top-teams");

export const getGovernanceSummary =
  () => api.get("/api/governance/summary");

export const getGovernanceScores =
  () => api.get("/api/governance/scores");

export const getDuplicates =
  () => api.get("/api/duplicates");

export const getDigest =
  () => api.get("/api/notifications/digest");

  export const getAgents =
  () => api.get("/api/agents");