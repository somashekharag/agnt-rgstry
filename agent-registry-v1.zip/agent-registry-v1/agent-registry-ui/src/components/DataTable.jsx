export default function DataTable({
    columns,
    data
  }) {
  
    return (
      <table className="min-w-full border bg-white">
  
        <thead>
  
          <tr className="bg-slate-100">
  
            {columns.map(column => (
  
              <th
                key={column.key}
                className="border p-3 text-left">
  
                {column.label}
  
              </th>
  
            ))}
  
          </tr>
  
        </thead>
  
        <tbody>
  
          {data.map((row, index) => (
  
            <tr
              key={index}
              className="hover:bg-slate-50">
  
              {columns.map(column => (
  
                <td
                  key={column.key}
                  className="border p-3">
  
                  {row[column.key]}
  
                </td>
  
              ))}
  
            </tr>
  
          ))}
  
        </tbody>
  
      </table>
    );
  }