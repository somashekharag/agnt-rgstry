export default function Header() {

    return (
      <div className="bg-white border-b p-4">
  
        <h1 className="text-2xl font-bold">
          Enterprise AI Agent Discovery,
          Governance and Adoption Platform
        </h1>
  
      </div>
    );
  }