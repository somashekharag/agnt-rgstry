export default function RatingBadge({ rating }) {

    let classes =
      "px-3 py-1 rounded text-sm font-medium";
  
    switch (rating) {
  
      case "GOLD":
        classes +=
          " bg-yellow-100 text-yellow-700";
        break;
  
      case "SILVER":
        classes +=
          " bg-slate-200 text-slate-700";
        break;
  
      case "BRONZE":
        classes +=
          " bg-orange-100 text-orange-700";
        break;
  
      default:
        classes +=
          " bg-red-100 text-red-700";
    }
  
    return (
      <span className={classes}>
        {rating}
      </span>
    );
  }