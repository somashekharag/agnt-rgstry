import { Link } from "react-router-dom";

export default function Sidebar() {

  return (
    <div className="w-64 bg-slate-900 text-white min-h-screen">

      <div className="p-4 text-xl font-bold">
        X Agent Registry
      </div>

      <nav className="flex flex-col">

        <Link
          className="p-3 hover:bg-slate-700"
          to="/">
          Dashboard
        </Link>

        <Link
          className="p-3 hover:bg-slate-700"
          to="/agents">
          Agent Catalog
        </Link>

        <Link
          className="p-3 hover:bg-slate-700"
          to="/usage">
          Usage Analytics
        </Link>

        <Link
          className="p-3 hover:bg-slate-700"
          to="/governance">
          Governance
        </Link>

        <Link
          className="p-3 hover:bg-slate-700"
          to="/duplicates">
          Duplicates
        </Link>

        <Link
          className="p-3 hover:bg-slate-700"
          to="/notifications">
          Notifications
        </Link>

      </nav>
    </div>
  );
}