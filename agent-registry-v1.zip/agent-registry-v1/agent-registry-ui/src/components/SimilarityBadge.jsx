export default function SimilarityBadge({
    score
  }) {
  
    let classes =
      "px-3 py-1 rounded text-sm font-medium";
  
    if (score >= 90) {
  
      classes +=
        " bg-red-100 text-red-700";
  
    } else if (score >= 80) {
  
      classes +=
        " bg-orange-100 text-orange-700";
  
    } else {
  
      classes +=
        " bg-yellow-100 text-yellow-700";
    }
  
    return (
      <span className={classes}>
        {score}%
      </span>
    );
  }