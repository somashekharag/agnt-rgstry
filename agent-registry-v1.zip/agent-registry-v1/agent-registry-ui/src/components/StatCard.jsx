export default function StatCard({
    title,
    value
  }) {
  
    return (
      <div className="bg-white rounded-lg shadow p-5">
  
        <div className="text-gray-500">
          {title}
        </div>
  
        <div className="text-3xl font-bold">
          {value}
        </div>
  
      </div>
    );
  }