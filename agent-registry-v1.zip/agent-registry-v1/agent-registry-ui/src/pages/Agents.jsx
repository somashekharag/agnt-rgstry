import { useEffect, useState } from "react";

import DataTable from "../components/DataTable";

import { getAgents }
  from "../api/agentRegistryApi";

export default function Agents() {

  const [agents, setAgents] =
    useState([]);

  const [search, setSearch] =
    useState("");

  useEffect(() => {

    loadAgents();

  }, []);

  const loadAgents = async () => {

    const response =
      await getAgents();

    setAgents(response.data);
  };

  const filteredAgents =
    agents.filter(agent =>

      agent.agentName
        ?.toLowerCase()
        .includes(
          search.toLowerCase()
        )

      ||

      agent.agentId
        ?.toLowerCase()
        .includes(
          search.toLowerCase()
        )

      ||

      agent.ownerTeam
        ?.toLowerCase()
        .includes(
          search.toLowerCase()
        )

    );

  const columns = [

    {
      key: "agentId",
      label: "Agent ID"
    },

    {
      key: "agentName",
      label: "Agent Name"
    },

    {
      key: "ownerTeam",
      label: "Owner Team"
    },

    {
      key: "status",
      label: "Status"
    },

    {
      key: "version",
      label: "Version"
    }

  ];

  return (

    <div>

      <div className="flex justify-between mb-6">

        <h2 className="text-2xl font-bold">

          Agent Catalog

        </h2>

      </div>

      <div className="mb-4">

        <input
          type="text"
          placeholder="Search agents..."
          value={search}
          onChange={(e) =>
            setSearch(e.target.value)}
          className="
            border
            rounded
            p-2
            w-96
          "
        />

      </div>

      <div className="mb-3">

        <span
          className="
          text-gray-600
        ">

          Total Agents:
          {" "}
          {filteredAgents.length}

        </span>

      </div>

      <DataTable
        columns={columns}
        data={filteredAgents}
      />

    </div>
  );
}