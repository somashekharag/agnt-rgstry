import { useEffect, useState } from "react";
import { getOverview } from "../api/agentRegistryApi";
import StatCard from "../components/StatCard";

export default function Dashboard() {

  const [overview, setOverview] =
    useState(null);

  useEffect(() => {

    getOverview()
      .then(res => setOverview(res.data));

  }, []);

  if (!overview) {
    return <div>Loading...</div>;
  }

  return (

    <div>

      <h2 className="text-2xl font-bold mb-6">
        Dashboard Overview
      </h2>

      <div className="grid grid-cols-4 gap-4">

        <StatCard
          title="Total Agents"
          value={overview.totalAgents}
        />

        <StatCard
          title="Active Agents"
          value={overview.activeAgents}
        />

        <StatCard
          title="Dormant Agents"
          value={overview.dormantAgents}
        />

        <StatCard
          title="Executions"
          value={overview.totalExecutions}
        />

      </div>

    </div>
  );
}