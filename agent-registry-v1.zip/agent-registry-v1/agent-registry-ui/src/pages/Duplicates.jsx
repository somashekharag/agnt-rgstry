import { useEffect, useState }
from "react";

import {
  getDuplicates
}
from "../api/agentRegistryApi";

import SimilarityBadge
from "../components/SimilarityBadge";


export default function Duplicates() {

  const [duplicates,
        setDuplicates]
        = useState([]);

  useEffect(() => {

    loadDuplicates();

  }, []);

  const loadDuplicates =
    async () => {

      const response =
        await getDuplicates();

      setDuplicates(
        response.data
      );
    };


  return (

    
    <div>

      <h2
        className="
          text-2xl
          font-bold
          mb-6
        ">

        Duplicate Detection

      </h2>

      <div
        className="
          mb-4
          text-gray-600
        ">

        Potential duplicate
        agents detected
        using similarity
        analysis.

      </div>

      <div
        className="
          bg-white
          rounded
          shadow
        ">

        <table
          className="
            min-w-full
          ">

          <thead>

            <tr
              className="
                bg-slate-100
              ">

              <th
                className="
                  p-3
                  text-left
                ">
                Source Agent
              </th>

              <th
                className="
                  p-3
                  text-left
                ">
                Candidate Agent
              </th>

              <th
                className="
                  p-3
                  text-left
                ">
                Similarity
              </th>

              <th
                className="
                  p-3
                  text-left
                ">
                Status
              </th>

            </tr>

          </thead>

          <tbody>

            {duplicates.map(
              duplicate => (

              <tr
                key={
                  duplicate.id
                }
                className="
                  border-t
                ">

                <td
                  className="
                    p-3
                  ">

                  <div>
                    {
                      duplicate
                      .sourceAgentName
                    }
                  </div>

                  <div
                    className="
                    text-xs
                    text-gray-500
                    ">

                    {
                      duplicate
                      .sourceAgentId
                    }

                  </div>

                </td>

                <td
                  className="
                    p-3
                  ">

                  <div>
                    {
                      duplicate
                      .candidateAgentName
                    }
                  </div>

                  <div
                    className="
                    text-xs
                    text-gray-500
                    ">

                    {
                      duplicate
                      .candidateAgentId
                    }

                  </div>

                </td>

                <td
                  className="
                    p-3
                  ">

                  <SimilarityBadge
                    score={
                      duplicate
                      .similarityScore
                    }
                  />

                </td>

                <td
                  className="
                    p-3
                  ">

                  <span
                    className="
                    bg-red-100
                    text-red-700
                    px-3
                    py-1
                    rounded
                    text-sm
                    ">

                    {
                      duplicate
                      .status
                    }

                  </span>

                </td>

              </tr>

            ))}

          </tbody>

        </table>

      </div>

    </div>
  );

  {
    duplicates.length === 0 && (
  
      <div
        className="
          bg-green-50
          text-green-700
          p-4
          rounded
        ">
  
        No duplicate agents detected.
  
      </div>
    )
  }
}