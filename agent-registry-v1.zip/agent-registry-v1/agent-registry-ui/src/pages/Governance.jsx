import { useEffect, useState } from "react";

import StatCard
  from "../components/StatCard";

import RatingBadge
  from "../components/RatingBadge";

import {
  getGovernanceSummary,
  getGovernanceScores
}
from "../api/agentRegistryApi";

export default function Governance() {

  const [summary, setSummary] =
    useState(null);

  const [scores, setScores] =
    useState([]);

  useEffect(() => {

    loadData();

  }, []);

  const loadData = async () => {

    const summaryResponse =
      await getGovernanceSummary();

    const scoreResponse =
      await getGovernanceScores();

    setSummary(
      summaryResponse.data
    );

    setScores(
      scoreResponse.data
    );
  };

  if (!summary) {

    return (
      <div>
        Loading...
      </div>
    );
  }

  return (

    <div>

      <h2
        className="
          text-2xl
          font-bold
          mb-6
        ">

        Governance Dashboard

      </h2>

      <div
        className="
          grid
          grid-cols-4
          gap-4
          mb-8
        ">

        <StatCard
          title="Gold Agents"
          value={summary.goldAgents}
        />

        <StatCard
          title="Silver Agents"
          value={summary.silverAgents}
        />

        <StatCard
          title="Bronze Agents"
          value={summary.bronzeAgents}
        />

        <StatCard
          title="At Risk"
          value={summary.atRiskAgents}
        />

      </div>

      <div
        className="
          bg-white
          rounded
          shadow
        ">

        <table
          className="
            min-w-full
          ">

          <thead>

            <tr
              className="
                bg-slate-100
              ">

              <th
                className="
                  p-3
                  text-left
                ">
                Agent ID
              </th>

              <th
                className="
                  p-3
                  text-left
                ">
                Agent Name
              </th>

              <th
                className="
                  p-3
                  text-left
                ">
                Score
              </th>

              <th
                className="
                  p-3
                  text-left
                ">
                Rating
              </th>

            </tr>

          </thead>

          <tbody>

            {scores.map(score => (

              <tr
                key={score.agentId}
                className="
                  border-t
                ">

                <td
                  className="p-3">

                  {score.agentId}

                </td>

                <td
                  className="p-3">

                  {score.agentName}

                </td>

                <td
                  className="p-3">

                  {score.score}

                </td>

                <td
                  className="p-3">

                  <RatingBadge
                    rating={
                      score.rating
                    }
                  />

                </td>

              </tr>

            ))}

          </tbody>

        </table>

      </div>

    </div>
  );
}