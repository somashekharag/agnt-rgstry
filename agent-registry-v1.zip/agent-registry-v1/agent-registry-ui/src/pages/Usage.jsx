export default function Usage() {
    return <div>Usage Analytics</div>;
  }