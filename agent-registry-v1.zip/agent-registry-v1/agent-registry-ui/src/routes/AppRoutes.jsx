import { Routes, Route } from "react-router-dom";

import Dashboard from "../pages/Dashboard";
import Agents from "../pages/Agents";
import Usage from "../pages/Usage";
import Governance from "../pages/Governance";
import Duplicates from "../pages/Duplicates";
import Notifications from "../pages/Notifications";

import MainLayout from "../layouts/MainLayout";

export default function AppRoutes() {

  return (

    <MainLayout>

      <Routes>

        <Route
          path="/"
          element={<Dashboard />}
        />

        <Route
          path="/agents"
          element={<Agents />}
        />

        <Route
          path="/usage"
          element={<Usage />}
        />

        <Route
          path="/governance"
          element={<Governance />}
        />

        <Route
          path="/duplicates"
          element={<Duplicates />}
        />

        <Route
          path="/notifications"
          element={<Notifications />}
        />

      </Routes>

    </MainLayout>
  );
}